package com.tapadoo.alerter;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Test Suite
 *
 * @author Kevin Murphy, Tapadoo
 * @since 12/01/2018
 **/
// Runs all unit tests.
@RunWith(Suite.class)
@Suite.SuiteClasses({AlertTest.class, AlertTest.class})
public class TestSuite {
}
